;root{
    
    --cor-de-fundo:  #1E1E1E;
    --verde;  #6FFF57;
    --branco:  #FFFFFF;
    --botao-ativo:  #3A375E;

}